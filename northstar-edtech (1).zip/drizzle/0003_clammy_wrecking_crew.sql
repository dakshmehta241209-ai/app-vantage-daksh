CREATE TABLE `assignmentSubmissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assignmentId` int NOT NULL,
	`studentAccountId` int NOT NULL,
	`response` text NOT NULL,
	`feedback` text,
	`grade` int,
	`status` enum('submitted','reviewed') NOT NULL DEFAULT 'submitted',
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `assignmentSubmissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`facultyAccountId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`courseCode` varchar(40) NOT NULL,
	`description` text NOT NULL,
	`dueDate` timestamp NOT NULL,
	`points` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assignments_id` PRIMARY KEY(`id`)
);
