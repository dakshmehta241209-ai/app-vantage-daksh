CREATE TABLE `northstarAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(120) NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`role` enum('student','faculty','coordinator','admin') NOT NULL,
	`profileJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `northstarAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `northstarAccounts_username_unique` UNIQUE(`username`),
	CONSTRAINT `northstarAccounts_email_unique` UNIQUE(`email`)
);
