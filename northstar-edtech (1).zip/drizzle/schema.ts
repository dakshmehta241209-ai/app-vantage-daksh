import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const northstarAccounts = mysqlTable("northstarAccounts", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 120 }).notNull().unique(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["student", "faculty", "coordinator", "admin"]).notNull(),
  profileJson: text("profileJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NorthstarAccount = typeof northstarAccounts.$inferSelect;
export type InsertNorthstarAccount = typeof northstarAccounts.$inferInsert;

export const fees = mysqlTable("fees", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  amount: int("amount").notNull(),
  paidAmount: int("paidAmount").default(0).notNull(),
  dueDate: timestamp("dueDate").notNull(),
  status: mysqlEnum("status", ["paid", "pending", "overdue"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Fee = typeof fees.$inferSelect;

export const feeTransactions = mysqlTable("feeTransactions", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  feeId: int("feeId").notNull(),
  amount: int("amount").notNull(),
  status: mysqlEnum("status", ["paid", "pending", "overdue"]).default("pending").notNull(),
  transactionId: varchar("transactionId", { length: 120 }).notNull().unique(),
  receiptNumber: varchar("receiptNumber", { length: 120 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type FeeTransaction = typeof feeTransactions.$inferSelect;

export const schedules = mysqlTable("schedules", {
  id: int("id").autoincrement().primaryKey(),
  role: mysqlEnum("role", ["student", "faculty", "coordinator", "admin"]).notNull(),
  department: varchar("department", { length: 120 }),
  semester: varchar("semester", { length: 40 }),
  subjectTitle: varchar("subjectTitle", { length: 160 }).notNull(),
  courseCode: varchar("courseCode", { length: 40 }).notNull(),
  facultyName: varchar("facultyName", { length: 120 }),
  startsAt: timestamp("startsAt").notNull(),
  endsAt: timestamp("endsAt").notNull(),
  location: varchar("location", { length: 120 }),
  virtualUrl: varchar("virtualUrl", { length: 500 }),
  materialUrl: varchar("materialUrl", { length: 500 }),
  status: mysqlEnum("status", ["upcoming", "live", "completed", "cancelled"]).default("upcoming").notNull(),
});
export type Schedule = typeof schedules.$inferSelect;

export const assignments = mysqlTable("assignments", {
  id: int("id").autoincrement().primaryKey(),
  facultyAccountId: int("facultyAccountId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  courseCode: varchar("courseCode", { length: 40 }).notNull(),
  description: text("description").notNull(),
  dueDate: timestamp("dueDate").notNull(),
  points: int("points"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Assignment = typeof assignments.$inferSelect;

export const assignmentSubmissions = mysqlTable("assignmentSubmissions", {
  id: int("id").autoincrement().primaryKey(),
  assignmentId: int("assignmentId").notNull(),
  studentAccountId: int("studentAccountId").notNull(),
  response: text("response").notNull(),
  feedback: text("feedback"),
  grade: int("grade"),
  status: mysqlEnum("status", ["submitted", "reviewed"]).default("submitted").notNull(),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});
export type AssignmentSubmission = typeof assignmentSubmissions.$inferSelect;

export const attendanceRecords = mysqlTable("attendanceRecords", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  subject: varchar("subject", { length: 160 }).notNull(),
  conductedClasses: int("conductedClasses").default(0).notNull(),
  presentClasses: int("presentClasses").default(0).notNull(),
  status: mysqlEnum("status", ["present", "absent", "excused"]).default("present").notNull(),
  classDate: timestamp("classDate").notNull(),
});
export type AttendanceRecord = typeof attendanceRecords.$inferSelect;

export const absenceReasons = mysqlTable("absenceReasons", {
  id: int("id").autoincrement().primaryKey(),
  attendanceId: int("attendanceId").notNull(),
  accountId: int("accountId").notNull(),
  subject: varchar("subject", { length: 160 }).notNull(),
  category: mysqlEnum("category", ["medical", "personal", "official_event", "transportation"]).notNull(),
  notes: text("notes").notNull(),
  documentUrl: varchar("documentUrl", { length: 500 }),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type AbsenceReason = typeof absenceReasons.$inferSelect;

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  actionRequired: int("actionRequired").default(0).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Notification = typeof notifications.$inferSelect;

export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  detail: text("detail").notNull(),
  startsAt: timestamp("startsAt").notNull(),
  registrations: int("registrations").default(0).notNull(),
  status: mysqlEnum("status", ["draft", "published", "cancelled"]).default("published").notNull(),
});
export type Event = typeof events.$inferSelect;

export const portfolioEntries = mysqlTable("portfolioEntries", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  type: varchar("type", { length: 60 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description").notNull(),
  certificateUrl: varchar("certificateUrl", { length: 500 }),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PortfolioEntry = typeof portfolioEntries.$inferSelect;

export const passwordResetTokens = mysqlTable("passwordResetTokens", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  otpHash: varchar("otpHash", { length: 128 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
