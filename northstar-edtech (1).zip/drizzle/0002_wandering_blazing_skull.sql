CREATE TABLE `absenceReasons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`attendanceId` int NOT NULL,
	`accountId` int NOT NULL,
	`subject` varchar(160) NOT NULL,
	`category` enum('medical','personal','official_event','transportation') NOT NULL,
	`notes` text NOT NULL,
	`documentUrl` varchar(500),
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `absenceReasons_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `attendanceRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`subject` varchar(160) NOT NULL,
	`conductedClasses` int NOT NULL DEFAULT 0,
	`presentClasses` int NOT NULL DEFAULT 0,
	`status` enum('present','absent','excused') NOT NULL DEFAULT 'present',
	`classDate` timestamp NOT NULL,
	CONSTRAINT `attendanceRecords_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(180) NOT NULL,
	`detail` text NOT NULL,
	`startsAt` timestamp NOT NULL,
	`registrations` int NOT NULL DEFAULT 0,
	`status` enum('draft','published','cancelled') NOT NULL DEFAULT 'published',
	CONSTRAINT `events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `feeTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`feeId` int NOT NULL,
	`amount` int NOT NULL,
	`status` enum('paid','pending','overdue') NOT NULL DEFAULT 'pending',
	`transactionId` varchar(120) NOT NULL,
	`receiptNumber` varchar(120),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `feeTransactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `feeTransactions_transactionId_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE TABLE `fees` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`category` varchar(80) NOT NULL,
	`amount` int NOT NULL,
	`paidAmount` int NOT NULL DEFAULT 0,
	`dueDate` timestamp NOT NULL,
	`status` enum('paid','pending','overdue') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fees_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`category` varchar(80) NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`actionRequired` int NOT NULL DEFAULT 0,
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `passwordResetTokens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`tokenHash` varchar(128) NOT NULL,
	`otpHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`usedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `passwordResetTokens_id` PRIMARY KEY(`id`),
	CONSTRAINT `passwordResetTokens_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `portfolioEntries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`type` varchar(60) NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`certificateUrl` varchar(500),
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `portfolioEntries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`role` enum('student','faculty','coordinator','admin') NOT NULL,
	`department` varchar(120),
	`semester` varchar(40),
	`subjectTitle` varchar(160) NOT NULL,
	`courseCode` varchar(40) NOT NULL,
	`facultyName` varchar(120),
	`startsAt` timestamp NOT NULL,
	`endsAt` timestamp NOT NULL,
	`location` varchar(120),
	`virtualUrl` varchar(500),
	`materialUrl` varchar(500),
	`status` enum('upcoming','live','completed','cancelled') NOT NULL DEFAULT 'upcoming',
	CONSTRAINT `schedules_id` PRIMARY KEY(`id`)
);
