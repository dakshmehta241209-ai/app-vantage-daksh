import { and, desc, eq, isNull } from "drizzle-orm";
import { getDb } from "./db";
import { absenceReasons, assignmentSubmissions, assignments, attendanceRecords, events, feeTransactions, fees, notifications, northstarAccounts, passwordResetTokens, portfolioEntries, schedules } from "../drizzle/schema";

export async function getFeeForAccount(accountId: number, feeId: number) {
  const db = await getDb();
  return db ? db.select().from(fees).where(and(eq(fees.accountId, accountId), eq(fees.id, feeId))).limit(1).then(rows => rows[0]) : undefined;
}

export async function listAllFees() {
  const db = await getDb();
  return db ? db.select().from(fees).orderBy(desc(fees.dueDate)) : [];
}

export async function updateFeeRecord(id: number, values: { amount: number; paidAmount: number; dueDate: Date; status: "paid" | "pending" | "overdue" }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(fees).set(values).where(eq(fees.id, id));
  return db.select().from(fees).where(eq(fees.id, id)).limit(1).then(rows => rows[0]);
}

export async function listPendingAbsences() {
  const db = await getDb();
  return db ? db.select().from(absenceReasons).where(eq(absenceReasons.status, "pending")).orderBy(desc(absenceReasons.createdAt)) : [];
}

export async function listFees(accountId: number) {
  const db = await getDb();
  return db ? db.select().from(fees).where(eq(fees.accountId, accountId)).orderBy(desc(fees.dueDate)) : [];
}

export async function listTransactions(accountId: number) {
  const db = await getDb();
  return db ? db.select().from(feeTransactions).where(eq(feeTransactions.accountId, accountId)).orderBy(desc(feeTransactions.createdAt)) : [];
}

export async function createPayment(input: { accountId: number; feeId: number; amount: number; transactionId: string; receiptNumber?: string }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(feeTransactions).values({ ...input, status: "paid" });
  const fee = await db.select().from(fees).where(and(eq(fees.id, input.feeId), eq(fees.accountId, input.accountId))).limit(1);
  if (fee[0]) await db.update(fees).set({ paidAmount: fee[0].paidAmount + input.amount, status: fee[0].paidAmount + input.amount >= fee[0].amount ? "paid" : "pending" }).where(eq(fees.id, input.feeId));
  return listTransactions(input.accountId);
}

export async function listSchedules(role: "student" | "faculty" | "coordinator" | "admin", department?: string, semester?: string) {
  const db = await getDb();
  if (!db) return [];
  const filters = [eq(schedules.role, role)];
  if (department) filters.push(eq(schedules.department, department));
  if (semester) filters.push(eq(schedules.semester, semester));
  return db.select().from(schedules).where(and(...filters)).orderBy(schedules.startsAt);
}

export async function listAssignments() {
  const db = await getDb();
  return db ? db.select().from(assignments).orderBy(desc(assignments.createdAt)) : [];
}

export async function createAssignment(input: { facultyAccountId: number; title: string; courseCode: string; description: string; dueDate: Date; points?: number }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(assignments).values(input);
  return listAssignments();
}

export async function listSubmissions(assignmentId?: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(assignmentSubmissions).where(assignmentId ? eq(assignmentSubmissions.assignmentId, assignmentId) : undefined).orderBy(desc(assignmentSubmissions.submittedAt));
}

export async function submitAssignment(input: { assignmentId: number; studentAccountId: number; response: string }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(assignmentSubmissions).values(input);
  return listSubmissions(input.assignmentId);
}

export async function reviewAssignment(input: { id: number; feedback?: string; grade?: number }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(assignmentSubmissions).set({ feedback: input.feedback, grade: input.grade, status: "reviewed", reviewedAt: new Date() }).where(eq(assignmentSubmissions.id, input.id));
  return db.select().from(assignmentSubmissions).where(eq(assignmentSubmissions.id, input.id)).limit(1).then(rows => rows[0]);
}

export async function listAllAttendance() {
  const db = await getDb();
  return db ? db.select().from(attendanceRecords).orderBy(desc(attendanceRecords.classDate)) : [];
}

export async function markAttendance(input: { id: number; status: "present" | "absent" | "excused"; presentClasses: number }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(attendanceRecords).set({ status: input.status, presentClasses: input.presentClasses }).where(eq(attendanceRecords.id, input.id));
  return db.select().from(attendanceRecords).where(eq(attendanceRecords.id, input.id)).limit(1).then(rows => rows[0]);
}

export async function listAttendance(accountId: number) {
  const db = await getDb();
  return db ? db.select().from(attendanceRecords).where(eq(attendanceRecords.accountId, accountId)).orderBy(desc(attendanceRecords.classDate)) : [];
}

export async function submitAbsence(input: { attendanceId: number; accountId: number; subject: string; category: "medical" | "personal" | "official_event" | "transportation"; notes: string; documentUrl?: string }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(absenceReasons).values(input);
  return db.select().from(absenceReasons).where(and(eq(absenceReasons.accountId, input.accountId), eq(absenceReasons.attendanceId, input.attendanceId))).orderBy(desc(absenceReasons.createdAt)).limit(1).then(rows => rows[0]);
}

export async function listAbsences(accountId: number) {
  const db = await getDb();
  return db ? db.select().from(absenceReasons).where(eq(absenceReasons.accountId, accountId)).orderBy(desc(absenceReasons.createdAt)) : [];
}

export async function reviewAbsence(id: number, status: "approved" | "rejected") {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(absenceReasons).set({ status }).where(eq(absenceReasons.id, id));
  const reason = await db.select().from(absenceReasons).where(eq(absenceReasons.id, id)).limit(1);
  if (reason[0] && status === "approved") await db.update(attendanceRecords).set({ status: "excused", presentClasses: 1 }).where(eq(attendanceRecords.id, reason[0].attendanceId));
  return reason[0];
}

export async function createNotification(input: { accountId: number; category: string; title: string; body: string; actionRequired?: boolean }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(notifications).values({ accountId: input.accountId, category: input.category, title: input.title, body: input.body, actionRequired: input.actionRequired ? 1 : 0 });
  return true;
}

export async function listNotifications(accountId: number) {
  const db = await getDb();
  return db ? db.select().from(notifications).where(eq(notifications.accountId, accountId)).orderBy(desc(notifications.createdAt)) : [];
}

export async function markNotificationRead(accountId: number, id: number) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.id, id), eq(notifications.accountId, accountId)));
  return true;
}

export async function listEvents() {
  const db = await getDb();
  return db ? db.select().from(events).where(eq(events.status, "published")).orderBy(events.startsAt) : [];
}

export async function listPendingPortfolio() {
  const db = await getDb();
  return db ? db.select().from(portfolioEntries).where(eq(portfolioEntries.status, "pending")).orderBy(desc(portfolioEntries.createdAt)) : [];
}

export async function reviewPortfolio(id: number, status: "approved" | "rejected") {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(portfolioEntries).set({ status }).where(eq(portfolioEntries.id, id));
  return db.select().from(portfolioEntries).where(eq(portfolioEntries.id, id)).limit(1).then(rows => rows[0]);
}

export async function listPortfolio(accountId: number) {
  const db = await getDb();
  return db ? db.select().from(portfolioEntries).where(eq(portfolioEntries.accountId, accountId)).orderBy(desc(portfolioEntries.createdAt)) : [];
}

export async function createPortfolioEntry(input: { accountId: number; type: string; title: string; description: string; certificateUrl?: string }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(portfolioEntries).values(input);
  return listPortfolio(input.accountId);
}

export async function saveResetToken(input: { accountId: number; tokenHash: string; otpHash: string; expiresAt: Date }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(passwordResetTokens).values(input);
  return true;
}

export async function getValidResetToken(tokenHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  return db.select().from(passwordResetTokens).where(and(eq(passwordResetTokens.tokenHash, tokenHash), isNull(passwordResetTokens.usedAt))).limit(1).then(rows => rows[0]);
}

export async function consumeResetToken(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, id));
  return true;
}

export async function updateAccountPassword(accountId: number, passwordHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(northstarAccounts).set({ passwordHash }).where(eq(northstarAccounts.id, accountId));
  return true;
}
