import { describe, expect, it } from "vitest";

describe("northstar role passcodes", () => {
  it("loads the three privileged role passcodes from server environment variables", () => {
    expect(process.env.NORTHSTAR_FACULTY_PASSCODE).toBe("faculty@123");
    expect(process.env.NORTHSTAR_COORDINATOR_PASSCODE).toBe("coordinator@123");
    expect(process.env.NORTHSTAR_ADMIN_PASSCODE).toBe("admin@123");
  });
});
