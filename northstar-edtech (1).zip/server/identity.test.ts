import { describe, expect, it } from "vitest";
import { DEFAULT_USER, getDisplayName, getInitials, parseStoredUser, serializeUser } from "../client/src/session";

describe("Northstar identity helpers", () => {
  it("uses the username captured during sign-up as the display name", () => {
    expect(getDisplayName({ name: "River Chen", username: "River Chen", email: "river@example.com", role: "student" })).toBe("River Chen");
  });

  it("falls back to the email handle only when no username is available", () => {
    expect(getDisplayName({ name: "", email: "sam@example.com", role: "student" })).toBe("sam");
    expect(getDisplayName({ name: "sam@example.com", username: "sam@example.com", email: "sam@example.com", role: "student" })).toBe("sam");
    expect(getDisplayName(null)).toBe(DEFAULT_USER.name);
  });

  it("creates compact initials without depending on a fixed identity", () => {
    expect(getInitials("River Chen")).toBe("RC");
    expect(getInitials("Single")).toBe("S");
    expect(getInitials("")).toBe("NU");
  });

  it("round-trips the signed-up username and profile payload through session storage", () => {
    const stored = serializeUser({ id: 42, name: "River Chen", username: "River Chen", email: "river@example.com", role: "student", profileJson: JSON.stringify({ department: "Computer Science" }) });
    expect(parseStoredUser(stored)).toMatchObject({ id: 42, name: "River Chen", username: "River Chen", role: "student", profileJson: JSON.stringify({ department: "Computer Science" }) });
  });
});
