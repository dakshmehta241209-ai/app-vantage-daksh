export async function sendPasswordResetEmail(input: { to: string; username: string; token: string; otp: string; origin: string }) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) throw new Error("Resend is not configured.");
  const resetUrl = `${input.origin}/auth/reset-password?token=${encodeURIComponent(input.token)}`;
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: "Northstar EDU <onboarding@resend.dev>",
      to: [input.to],
      subject: "Reset your Northstar EDU password",
      html: `<p>Hello ${input.username},</p><p>Your Northstar EDU verification code is <strong>${input.otp}</strong>. It expires in 15 minutes.</p><p><a href="${resetUrl}">Open the secure password reset page</a></p>`,
    }),
  });
  if (!response.ok) throw new Error(`Reset email delivery failed (${response.status})`);
  return true;
}
