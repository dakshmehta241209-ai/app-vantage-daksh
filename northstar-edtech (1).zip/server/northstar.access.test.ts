import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { hasPermission } from "../shared/permissions";
import type { TrpcContext } from "./_core/context";

describe("northstar access control", () => {
  it("accepts the configured faculty passcode and rejects a wrong one", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });
    await expect(caller.auth.verifyRole({ role: "faculty", passcode: "faculty@123" })).resolves.toEqual({ success: true });
    await expect(caller.auth.verifyRole({ role: "faculty", passcode: "wrong" })).resolves.toMatchObject({ success: false });
  });

  it("keeps role permissions distinct", () => {
    expect(hasPermission("student", "view_attendance")).toBe(true);
    expect(hasPermission("student", "manage_attendance")).toBe(false);
    expect(hasPermission("faculty", "review_submissions")).toBe(true);
    expect(hasPermission("faculty", "delete_users")).toBe(false);
    expect(hasPermission("admin", "delete_users")).toBe(true);
  });
});
