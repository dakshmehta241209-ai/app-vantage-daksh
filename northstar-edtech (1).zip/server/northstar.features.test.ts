import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const ctx = { user: null, req: { protocol: "https", headers: {} }, res: {} } as TrpcContext;

describe("Northstar feature procedures", () => {
  it("returns transparent advisor directions based on user-entered interests", async () => {
    const result = await appRouter.createCaller(ctx).advisor.recommend({ grades: "A", skills: "Python", interests: "data and analytics" });
    expect(result.recommendations).toContain("Data science");
  });

  it("rejects weak reset passwords at the validation boundary", async () => {
    await expect(appRouter.createCaller(ctx).passwordReset.reset({ token: "01234567890123456789", otp: "123456", password: "weakpass" })).rejects.toThrow();
  });

  it("rejects empty assignment briefs at the validation boundary", async () => {
    await expect(appRouter.createCaller(ctx).assignments.create({ facultyAccountId: 1, title: "", courseCode: "CSE 304", description: "", dueDate: new Date() })).rejects.toThrow();
  });

  it("rejects invalid attendance status values", async () => {
    await expect(appRouter.createCaller(ctx).attendance.mark({ requesterId: 1, id: 1, status: "late" as "present", presentClasses: 1 })).rejects.toThrow();
  });
});
