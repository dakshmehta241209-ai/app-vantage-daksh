import Stripe from "stripe";
import { getNorthstarAccountById } from "./db";
import { getFeeForAccount } from "./northstarDb";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2026-07-29.dahlia" });

export async function createFeeCheckout(input: { accountId: number; feeId: number; origin: string }) {
  if (!process.env.STRIPE_SECRET_KEY) throw new Error("Stripe is not configured. Connect Stripe in project settings first.");
  const [account, fee] = await Promise.all([getNorthstarAccountById(input.accountId), getFeeForAccount(input.accountId, input.feeId)]);
  if (!account || !fee) throw new Error("The account or fee record could not be found.");
  const outstanding = Math.max(0, fee.amount - fee.paidAmount);
  if (!outstanding) throw new Error("This fee is already paid.");
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: account.email,
    client_reference_id: String(account.id),
    allow_promotion_codes: true,
    line_items: [{ price_data: { currency: "inr", product_data: { name: `${fee.category} · Northstar EDU` }, unit_amount: outstanding }, quantity: 1 }],
    metadata: { user_id: String(account.id), customer_email: account.email, customer_name: account.username, fee_id: String(fee.id) },
    success_url: `${input.origin}/finance?payment=success`,
    cancel_url: `${input.origin}/finance?payment=cancelled`,
  });
  return session.url;
}

export { stripe };
