import { describe, expect, it } from "vitest";

describe("Resend configuration", () => {
  it("exposes the server-side Resend credential when configured", () => {
    expect(process.env.RESEND_API_KEY).toBeTruthy();
  });
});
