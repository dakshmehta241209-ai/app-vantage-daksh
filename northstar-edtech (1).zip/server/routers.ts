import { z } from "zod";
import { createHash, randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { COOKIE_NAME } from "@shared/const";
import { isNorthstarRole, hasPermission, type NorthstarPermission, type NorthstarRole } from "@shared/permissions";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { createNorthstarAccount, getNorthstarAccount, getNorthstarAccountById, updateNorthstarAccount } from "./db";
import { storagePut } from "./storage";
import { createFeeCheckout } from "./stripe";
import { sendPasswordResetEmail } from "./email";
import { consumeResetToken, createPayment, createPortfolioEntry, getValidResetToken, listAbsences, listAttendance, listEvents, listFees, listNotifications, listPortfolio, listSchedules, listTransactions, markNotificationRead, reviewAbsence, saveResetToken, submitAbsence, updateAccountPassword, listAllFees, updateFeeRecord, listPendingAbsences, listPendingPortfolio, reviewPortfolio, createNotification, listAssignments, createAssignment, listSubmissions, submitAssignment, reviewAssignment, listAllAttendance, markAttendance } from "./northstarDb";

const roleSchema = z.enum(["student", "faculty", "coordinator", "admin"]);
const passcodeFor = (role: Exclude<NorthstarRole, "student">) => {
  const envKey = role === "faculty" ? "NORTHSTAR_FACULTY_PASSCODE" : role === "coordinator" ? "NORTHSTAR_COORDINATOR_PASSCODE" : "NORTHSTAR_ADMIN_PASSCODE";
  return process.env[envKey];
};

const accountInput = z.object({ username: z.string().trim().min(1).max(120), email: z.string().email().max(320), password: z.string().min(6).max(200), role: roleSchema });
const hashPassword = (password: string) => { const salt = randomBytes(16).toString("hex"); return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`; };
const verifyPassword = (password: string, stored: string) => { const [salt, hash] = stored.split(":"); if (!salt || !hash) return false; const derived = scryptSync(password, salt, 64); return timingSafeEqual(derived, Buffer.from(hash, "hex")); };
const publicAccount = (account: Awaited<ReturnType<typeof getNorthstarAccount>>) => account && ({ id: account.id, username: account.username, name: account.username, email: account.email, role: account.role, profileJson: account.profileJson });
const assertReviewer = async (requesterId: number) => { const account = await getNorthstarAccountById(requesterId); if (!account || !["admin", "coordinator"].includes(account.role)) throw new Error("Reviewer access required."); return account; };

export const appRouter = router({
  system: systemRouter,
  admin: router({
    fees: publicProcedure.input(z.object({ requesterId: z.number().int().positive() })).query(async ({ input }) => { await assertReviewer(input.requesterId); return listAllFees(); }),
    updateFee: publicProcedure.input(z.object({ requesterId: z.number().int().positive(), id: z.number().int().positive(), amount: z.number().int().positive(), paidAmount: z.number().int().nonnegative(), dueDate: z.coerce.date(), status: z.enum(["paid", "pending", "overdue"]) })).mutation(async ({ input }) => { await assertReviewer(input.requesterId); return updateFeeRecord(input.id, input); }),
    pendingAbsences: publicProcedure.input(z.object({ requesterId: z.number().int().positive() })).query(async ({ input }) => { await assertReviewer(input.requesterId); return listPendingAbsences(); }),
    reviewAbsence: publicProcedure.input(z.object({ requesterId: z.number().int().positive(), id: z.number().int().positive(), status: z.enum(["approved", "rejected"]) })).mutation(async ({ input }) => { await assertReviewer(input.requesterId); return reviewAbsence(input.id, input.status); }),
    pendingPortfolio: publicProcedure.input(z.object({ requesterId: z.number().int().positive() })).query(async ({ input }) => { await assertReviewer(input.requesterId); return listPendingPortfolio(); }),
    reviewPortfolio: publicProcedure.input(z.object({ requesterId: z.number().int().positive(), id: z.number().int().positive(), status: z.enum(["approved", "rejected"]) })).mutation(async ({ input }) => { await assertReviewer(input.requesterId); return reviewPortfolio(input.id, input.status); }),
  }),
  finance: router({
    fees: publicProcedure.input(z.object({ accountId: z.number().int().positive() })).query(({ input }) => listFees(input.accountId)),
    transactions: publicProcedure.input(z.object({ accountId: z.number().int().positive() })).query(({ input }) => listTransactions(input.accountId)),
    pay: publicProcedure.input(z.object({ accountId: z.number().int().positive(), feeId: z.number().int().positive(), amount: z.number().int().positive() })).mutation(async ({ input }) => { const result = await createPayment({ ...input, transactionId: `NS-${randomUUID()}`, receiptNumber: `RCPT-${Date.now()}` }); await createNotification({ accountId: input.accountId, category: "fee", title: "Payment recorded", body: "Your fee payment has been recorded and a receipt is available." }); return result; }),
    checkout: publicProcedure.input(z.object({ accountId: z.number().int().positive(), feeId: z.number().int().positive() })).mutation(({ input, ctx }) => createFeeCheckout({ ...input, origin: `${ctx.req.protocol}://${ctx.req.headers.host || "localhost"}` })),
  }),
  assignments: router({
    list: publicProcedure.query(() => listAssignments()),
    create: publicProcedure.input(z.object({ facultyAccountId: z.number().int().positive(), title: z.string().trim().min(1).max(180), courseCode: z.string().trim().min(1).max(40), description: z.string().trim().min(1), dueDate: z.coerce.date(), points: z.number().int().positive().optional() })).mutation(async ({ input }) => { const faculty = await getNorthstarAccountById(input.facultyAccountId); if (!faculty || !["faculty", "admin"].includes(faculty.role)) return { success: false as const, message: "Faculty access required." }; return { success: true as const, assignments: await createAssignment(input) }; }),
    submissions: publicProcedure.input(z.object({ assignmentId: z.number().int().positive().optional() })).query(({ input }) => listSubmissions(input.assignmentId)),
    submit: publicProcedure.input(z.object({ assignmentId: z.number().int().positive(), studentAccountId: z.number().int().positive(), response: z.string().trim().min(1) })).mutation(async ({ input }) => { const result = await submitAssignment(input); await createNotification({ accountId: input.studentAccountId, category: "assignment", title: "Assignment submitted", body: "Your response has been submitted for faculty review." }); return { success: true as const, submissions: result }; }),
    review: publicProcedure.input(z.object({ reviewerAccountId: z.number().int().positive(), id: z.number().int().positive(), feedback: z.string().trim().optional(), grade: z.number().int().min(0).optional() })).mutation(async ({ input }) => { const reviewer = await getNorthstarAccountById(input.reviewerAccountId); if (!reviewer || !["faculty", "admin"].includes(reviewer.role)) return { success: false as const, message: "Faculty access required." }; return { success: true as const, submission: await reviewAssignment(input) }; }),
  }),
  schedule: router({
    list: publicProcedure.input(z.object({ role: roleSchema, department: z.string().optional(), semester: z.string().optional() })).query(({ input }) => listSchedules(input.role, input.department, input.semester)),
  }),
  attendance: router({
    list: publicProcedure.input(z.object({ accountId: z.number().int().positive() })).query(({ input }) => listAttendance(input.accountId)),
    summary: publicProcedure.input(z.object({ requesterId: z.number().int().positive() })).query(async ({ input }) => { const requester = await getNorthstarAccountById(input.requesterId); if (!requester || !["admin", "faculty"].includes(requester.role)) return []; return listAllAttendance(); }),
    mark: publicProcedure.input(z.object({ requesterId: z.number().int().positive(), id: z.number().int().positive(), status: z.enum(["present", "absent", "excused"]), presentClasses: z.number().int().nonnegative() })).mutation(async ({ input }) => { const requester = await getNorthstarAccountById(input.requesterId); if (!requester || !["faculty", "admin"].includes(requester.role)) return { success: false as const, message: "Faculty access required." }; return { success: true as const, record: await markAttendance(input) }; }),
    absences: publicProcedure.input(z.object({ accountId: z.number().int().positive() })).query(({ input }) => listAbsences(input.accountId)),
    submitAbsence: publicProcedure.input(z.object({ attendanceId: z.number().int().positive(), accountId: z.number().int().positive(), subject: z.string().min(1), category: z.enum(["medical", "personal", "official_event", "transportation"]), notes: z.string().min(10), documentUrl: z.string().url().optional() })).mutation(async ({ input }) => { const result = await submitAbsence(input); await createNotification({ accountId: input.accountId, category: "attendance", title: "Absence explanation submitted", body: `Your explanation for ${input.subject} is awaiting review.` }); return result; }),
    reviewAbsence: publicProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["approved", "rejected"]) })).mutation(({ input }) => reviewAbsence(input.id, input.status)),
  }),
  notifications: router({
    list: publicProcedure.input(z.object({ accountId: z.number().int().positive() })).query(({ input }) => listNotifications(input.accountId)),
    markRead: publicProcedure.input(z.object({ accountId: z.number().int().positive(), id: z.number().int().positive() })).mutation(({ input }) => markNotificationRead(input.accountId, input.id)),
  }),
  events: router({ list: publicProcedure.query(() => listEvents()) }),
  profile: router({
    upload: publicProcedure.input(z.object({ accountId: z.number().int().positive(), fileName: z.string().min(1).max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "application/pdf"]), base64: z.string().min(1).max(7_000_000), kind: z.enum(["avatar", "resume"]) })).mutation(async ({ input }) => {
      if (input.kind === "resume" && input.mimeType !== "application/pdf") return { success: false as const, message: "Resumes must be PDF files." };
      const raw = Buffer.from(input.base64, "base64"); if (input.kind === "resume" && raw.byteLength > 5 * 1024 * 1024) return { success: false as const, message: "Resume files must be 5MB or smaller." };
      const account = await getNorthstarAccountById(input.accountId); if (!account) return { success: false as const, message: "Account not found." };
      const upload = await storagePut(`northstar/${input.accountId}/${input.kind}/${input.fileName}`, raw, input.mimeType);
      let profile: Record<string, unknown> = {}; try { profile = account.profileJson ? JSON.parse(account.profileJson) : {}; } catch { profile = {}; }
      profile[input.kind === "avatar" ? "avatarUrl" : "resumeUrl"] = upload.url;
      await updateNorthstarAccount(input.accountId, { username: account.username, email: account.email, profileJson: JSON.stringify(profile) });
      return { success: true as const, url: upload.url, profileJson: JSON.stringify(profile) };
    }),
  }),
  portfolio: router({
    list: publicProcedure.input(z.object({ accountId: z.number().int().positive() })).query(({ input }) => listPortfolio(input.accountId)),
    create: publicProcedure.input(z.object({ accountId: z.number().int().positive(), type: z.string().min(1).max(60), title: z.string().min(1), description: z.string().min(1), certificateUrl: z.string().url().optional() })).mutation(async ({ input }) => { const result = await createPortfolioEntry(input); await createNotification({ accountId: input.accountId, category: "portfolio", title: "Portfolio entry submitted", body: `${input.title} is awaiting coordinator review.` }); return result; }),
  }),
  advisor: router({
    recommend: publicProcedure.input(z.object({ grades: z.string().max(2000), skills: z.string().max(2000), interests: z.string().max(2000) })).mutation(({ input }) => {
      const text = `${input.grades} ${input.skills} ${input.interests}`.toLowerCase();
      const recommendations = text.includes("design") || text.includes("react") ? ["Human-computer interaction", "Product design systems", "Frontend engineering"] : text.includes("data") || text.includes("python") ? ["Data science", "Applied machine learning", "Analytics engineering"] : ["Explore interdisciplinary electives", "Join a project-based club", "Book an academic advisor session"];
      return { recommendations };
    }),
  }),
  passwordReset: router({
    request: publicProcedure.input(z.object({ identifier: z.string().min(1) })).mutation(async ({ input, ctx }) => {
      const account = await getNorthstarAccount(input.identifier);
      if (!account) return { success: true as const, message: "If an account exists, reset instructions have been prepared." };
      const token = randomBytes(32).toString("hex"); const otp = String(Math.floor(100000 + Math.random() * 900000));
      await saveResetToken({ accountId: account.id, tokenHash: createHash("sha256").update(token).digest("hex"), otpHash: createHash("sha256").update(otp).digest("hex"), expiresAt: new Date(Date.now() + 15 * 60 * 1000) });
      try {
        await sendPasswordResetEmail({ to: account.email, username: account.username, token, otp, origin: `${ctx.req.protocol}://${ctx.req.headers.host || "localhost"}` });
      } catch (error) {
        console.warn("[Password reset] Email delivery unavailable; keeping privacy-safe response", error instanceof Error ? error.message : error);
      }
      return { success: true as const, message: "If the account exists, reset instructions have been prepared." };
    }),
    reset: publicProcedure.input(z.object({ token: z.string().min(10), otp: z.string().length(6), password: z.string().min(8).regex(/[A-Z]/).regex(/[a-z]/).regex(/[0-9]/).regex(/[^A-Za-z0-9]/) })).mutation(async ({ input }) => {
      const record = await getValidResetToken(createHash("sha256").update(input.token).digest("hex"));
      if (!record || record.expiresAt.getTime() < Date.now() || createHash("sha256").update(input.otp).digest("hex") !== record.otpHash) return { success: false as const, message: "That reset code is invalid or expired." };
      await updateAccountPassword(record.accountId, hashPassword(input.password)); await consumeResetToken(record.id); return { success: true as const };
    }),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    signUp: publicProcedure.input(accountInput).mutation(async ({ input }) => {
      const existing = await getNorthstarAccount(input.username) || await getNorthstarAccount(input.email);
      if (existing) return { success: false as const, message: "That username or email is already registered." };
      const account = await createNorthstarAccount({ username: input.username, email: input.email.toLowerCase(), passwordHash: hashPassword(input.password), role: input.role, profileJson: JSON.stringify({}) });
      if (!account) return { success: false as const, message: "Account storage is unavailable. Please try again." };
      return { success: true as const, user: publicAccount(account) };
    }),
    signIn: publicProcedure.input(z.object({ identifier: z.string().trim().min(1), password: z.string().min(6), role: roleSchema.optional() })).mutation(async ({ input }) => {
      const account = await getNorthstarAccount(input.identifier);
      if (!account || !verifyPassword(input.password, account.passwordHash)) return { success: false as const, message: "The username/email or password is incorrect." };
      if (input.role && account.role !== input.role) return { success: false as const, message: "This account belongs to a different role." };
      return { success: true as const, user: publicAccount(account) };
    }),
    updateProfile: publicProcedure.input(z.object({ id: z.number().int().positive(), username: z.string().trim().min(1).max(120), email: z.string().email().max(320), profileJson: z.string().max(10000) })).mutation(async ({ input }) => {
      const updated = await updateNorthstarAccount(input.id, { username: input.username, email: input.email.toLowerCase(), profileJson: input.profileJson });
      if (!updated) return { success: false as const, message: "Profile storage is unavailable. Please try again." };
      return { success: true as const, user: publicAccount(updated) };
    }),
    verifyRole: publicProcedure.input(z.object({ role: roleSchema, passcode: z.string().optional() })).mutation(({ input }) => {
      if (input.role === "student") return { success: true as const };
      const expected = passcodeFor(input.role);
      if (!expected || input.passcode !== expected) return { success: false as const, message: "That role passcode is not correct. Please try again." };
      return { success: true as const };
    }),
    checkPermission: protectedProcedure.input(z.object({ role: roleSchema, permission: z.string() })).query(({ input }) => ({
      allowed: isNorthstarRole(input.role) && hasPermission(input.role, input.permission as NorthstarPermission),
    })),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
