# Northstar EdTech

Northstar is a calm campus command center for students, faculty, coordinators, and administrators.

## Live site

https://northstaredu-hjnfsqav.manus.space

## Demo credentials

| Role | Email | Password |
|---|---|---|
| Student | `student@northstar.edu` | `Student123!` |
| Faculty | `faculty@northstar.edu` | `Faculty123!` |
| Coordinator | `coordinator@northstar.edu` | `Coordinator123!` |
| Admin | `admin@northstar.edu` | `Admin123!` |

The landing page and sign-in pages display these credentials. Use the **Use demo** action to fill the selected sign-in form.

## Implemented features

The application provides role-based dashboards, persistent Northstar accounts, protected role routes, logout and session persistence, dynamic username display, password recovery with reset-token validation and Resend delivery, profile editing with avatar and resume storage, finance records and Stripe Checkout scaffolding, timetable and resource links, attendance records and absence explanations, notifications with unread/action-required filters and polling, portfolio submissions with coordinator review, advisor guidance, and the persistent assignment workflow. Faculty can create assignments and review student submissions; students can submit responses; administrators can view operations and attendance summaries.

## Technology

The project uses React 19, TypeScript, Vite, Tailwind CSS 4, shadcn/ui primitives, Wouter, tRPC 11, Express, Drizzle ORM, MySQL/TiDB, Vitest, Stripe Checkout, Resend, and S3-compatible storage.

## Local setup

Install dependencies with `pnpm install`, then start the development server with `pnpm dev`. Run `pnpm check` for TypeScript validation and `pnpm test` for the Vitest suite. Database changes are represented in `drizzle/schema.ts` and generated migration files. Required secrets are provided through the project environment and must not be committed.

## Judge walkthrough

First open the live site and use the visible demo credentials. Sign in as Faculty, open Assignments, create a brief, and open Attendance to update a record. Sign out, sign in as Student, confirm the assignment is listed, submit a response, and review the updated attendance record. Sign out and enter the Faculty account again to inspect the submission queue. Finally, sign in as Admin and open Operations review or Attendance to see management-level data. Test a direct route from another role to confirm the friendly access-restricted state.

## Known limitations

Demo data is intentionally small and shared for judge walkthroughs. Stripe Checkout requires a claimed/test-configured sandbox for an external payment session. Password reset emails require a configured Resend sender/domain. File uploads use S3-backed storage, while some legacy campus modules remain informational rather than full institutional integrations. The sign-in screen exposes demo credentials for evaluation; production deployments should replace them and remove public demo credentials.
