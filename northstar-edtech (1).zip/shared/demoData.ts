export const demoAssignments = [
  { title: "Research brief · CSE 304", status: "Due tomorrow", type: "assignment" },
  { title: "Interaction audit · DES 215", status: "Needs review", type: "assignment" },
  { title: "System map · CSE 304L", status: "Submitted", type: "assignment" },
];

export const demoEvents = [
  { title: "Design Week 2026", detail: "412 registrations", date: "22 Apr", seats: 88 },
  { title: "Open Mic Night", detail: "88 registrations", date: "27 Apr", seats: 42 },
  { title: "Alumni Connect", detail: "Coming soon", date: "03 May", seats: 120 },
];

export const demoAttendance = [
  { subject: "CSE 304 · Data Structures", percentage: 92, sessions: 18 },
  { subject: "DES 215 · Interface Systems", percentage: 86, sessions: 16 },
  { subject: "HUM 210 · Design & Society", percentage: 84, sessions: 14 },
];

export const demoUsers = [
  { name: "Student account", email: "student@northstar.edu", role: "Student", status: "Active" },
  { name: "Faculty account", email: "faculty@northstar.edu", role: "Faculty", status: "Active" },
  { name: "Coordinator account", email: "coordinator@northstar.edu", role: "Coordinator", status: "Active" },
  { name: "Admin account", email: "admin@northstar.edu", role: "Admin", status: "Active" },
];

export const demoSystemLogs = [
  { event: "Role permission updated", actor: "System administrator", time: "1 hour ago" },
  { event: "Attendance report generated", actor: "Faculty workspace", time: "2 hours ago" },
  { event: "New faculty onboarded", actor: "System administrator", time: "Yesterday" },
];
