export type NorthstarRole = "student" | "faculty" | "coordinator" | "admin";

export type NorthstarPermission =
  | "view_dashboard" | "edit_profile" | "register_events" | "submit_assignments" | "view_attendance"
  | "view_placements" | "view_notifications" | "manage_clubs" | "create_assignments" | "upload_materials"
  | "manage_attendance" | "publish_notices" | "review_submissions" | "manage_events" | "approve_students"
  | "manage_users" | "delete_users" | "assign_roles" | "view_analytics" | "manage_settings" | "manage_permissions"
  | "view_reports" | "view_system_logs";

export const ROLE_PERMISSIONS: Record<NorthstarRole, readonly NorthstarPermission[]> = {
  student: ["view_dashboard", "edit_profile", "register_events", "submit_assignments", "view_attendance", "view_placements", "view_notifications", "manage_clubs"],
  faculty: ["view_dashboard", "create_assignments", "upload_materials", "manage_attendance", "publish_notices", "review_submissions"],
  coordinator: ["view_dashboard", "manage_events", "manage_clubs", "approve_students", "publish_notices"],
  admin: ["view_dashboard", "edit_profile", "register_events", "submit_assignments", "view_attendance", "view_placements", "view_notifications", "manage_clubs", "create_assignments", "upload_materials", "manage_attendance", "publish_notices", "review_submissions", "manage_events", "approve_students", "manage_users", "delete_users", "assign_roles", "view_analytics", "manage_settings", "manage_permissions", "view_reports", "view_system_logs"],
};

export function hasPermission(role: NorthstarRole, permission: NorthstarPermission) {
  return ROLE_PERMISSIONS[role].includes(permission);
}

export function isNorthstarRole(value: string): value is NorthstarRole {
  return value === "student" || value === "faculty" || value === "coordinator" || value === "admin";
}
