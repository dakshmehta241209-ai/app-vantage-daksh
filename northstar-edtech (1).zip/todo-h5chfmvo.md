# Project TODO

- [x] Replace every hard-coded personal name with the signed-in user's username or a safe fallback.
- [x] Persist the username entered during sign-up/sign-in in the active user session and make it available to all dashboard pages.
- [x] Make authentication, role selection, sign-out, and restricted-route behavior functional and consistent.
- [x] Make dashboard navigation and primary quick actions lead to usable flows with clear loading, empty, success, and error states.
- [x] Make profile editing save and display the current user's username and profile details.
- [x] Remove demo-only assumptions that cause the interface to show Daksh Mehta or other fixed identities.
- [x] Add or update Vitest coverage for username persistence and the key functional flows.
- [x] Verify the application with type-checking, tests, and browser screenshots at desktop and mobile sizes.
- [x] Save a checkpoint with all completed items marked complete.

## History

- [x] Initial inspection found the deployed bundle contained hard-coded `Daksh`/`Daksh Mehta` values and a localStorage-only demo authentication flow; the implementation now uses persisted backend accounts with session storage for the active account.
- [x] Initial inspection found the live sign-in flow accepts an email and password but no explicit sign-up form is exposed from the role chooser.
- [x] Initial inspection found the student dashboard renders the entered email username in the sidebar but still renders `Good morning, Daksh.` in the main greeting.


## Attached Change Specification

- [x] Add a production-ready finance data model and student finance dashboard with fee breakdowns, payment checkout flow, transaction history, receipts, and admin finance controls.
- [x] Add forgot-password and reset-password flows with expiring reset tokens, OTP/email integration boundary, password-strength validation, secure re-hashing, and session invalidation.
- [x] Add persisted schedule/class-resource data with weekly/daily timetable views, class metadata, virtual-classroom actions, and study-material links.
- [x] Add persisted attendance telemetry and mandatory absence-explanation workflow with review states and supporting-document metadata.
- [x] Add a persisted notification center with unread/action-required filters, categorized alerts, and live UI updates.
- [x] Extend the profile flow with validated personal details, avatar/resume metadata, preview/download actions, and comprehensive editable fields.
- [x] Add extracurricular portfolio records with certificate metadata and coordinator approval workflow.
- [x] Add an academic/career advisor module with a safe recommendation workflow based on student-entered academic and portfolio data.
- [x] Add regression coverage for the new data models, procedures, validation, and critical UI flows.
- [x] Verify the new modules with type-checking, tests, and responsive browser checks, then save a new checkpoint.

## Scope Notes for Attached Specification

- [x] Connect a live Stripe provider and webhook reconciliation; the finance page now creates hosted Checkout sessions and the raw webhook reconciles completed payments.
- [x] Configure Resend email delivery for reset links and OTPs; the credential is configured and reset requests now send a secure email without exposing OTPs to the browser.
- [x] Add admin fee-structure editing, manual fee review, and coordinator absence/portfolio review screens.
- [x] Add live notification behavior with persisted event writers, unread/action-required filters, and near-live polling for updated alerts.
- [x] Add in-app resume preview/download controls and avatar preview rendering for uploaded profile assets.

## Credential Update

- [x] Update the existing Jordan Lee test account email to `appvantage123@northstar.edu` and replace its password with the user-provided password, then verify sign-in and publish a checkpoint.

## Demo Login and Username Display

- [x] Replace the earlier preview-only any-credentials mode with explicit, judge-visible deterministic demo credentials and real production credential validation.
- [x] Display only the username portion before `@` in dashboard greetings, sidebar identity, and profile identity labels.
- [x] Verify the preview login and username formatting, then save a checkpoint.

## Attached Judge-Readiness Requirements

- [x] Add visible demo credentials for Student, Faculty, Coordinator, and Admin on landing/role/sign-in surfaces and README.
- [x] Make all four demo accounts deterministic and ensure sign-in routes each role to the correct dashboard.
- [x] Remove unrestricted demo bypass from production-facing behavior; sign-in uses backend credential validation and displays explicit demo accounts.
- [x] Harden sign-in validation for empty fields, malformed email, invalid credentials, loading state, and safe error messages.
- [x] Verify logout clears session and protected routes reject unauthorized roles with a friendly access-restricted page.
- [x] Complete the persistent Faculty → Student → Admin attendance workflow with visible status updates and summaries.
- [x] Complete the persistent Faculty → Student → Faculty assignment creation, submission, review, feedback, and optional grading workflow.
- [x] Clean unauthenticated password-reset navigation and validation, including a privacy-safe success state.
- [x] Remove or repair unfinished navigation, including the About Northstar link and dead routes.
- [x] Update README.md with live URL, credentials, implemented features, stack, local setup, limitations, and judge walkthrough.
- [x] Test all roles, workflows, logout, protected routes, password reset, responsive behavior, refreshes, and console errors before publishing.
- [x] Save a new checkpoint only after the requested acceptance criteria are actually verified.

## Acceptance Gaps Found During Judge Verification

- [x] Add the demo-credential panel or clear demo-access block to `/choose-role`.
- [x] Add explicit pending/disabled text states to sign-in and sign-up submit actions.
- [x] Refine faculty assignment review to use explicit feedback/grade save actions rather than mutating on every input change.
- [x] Audit primary navigation destinations for every role and replace remaining placeholder/dead routes with useful pages or clear states.
- [x] Browser-verify the updated gaps and save a fresh checkpoint.

## Urgent Deadline

- [x] Prioritize the highest-impact judge-readiness fixes and publish a validated checkpoint before the user's 3:45 deadline.

## Final Verification Gaps

- [x] Browser-test logout, protected-route rejection, password-reset submission, and refresh persistence.
- [x] Browser-test each primary navigation destination for Student, Faculty, Coordinator, and Admin, replacing any dead or placeholder destination found.
- [x] Browser-test the Faculty create → Student submit → Faculty save feedback/grade workflow end to end.
- [x] Mark the final acceptance and checkpoint items complete only after the above verification is recorded.
