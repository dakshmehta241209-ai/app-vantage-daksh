import FeatureFrame from "@/components/FeatureFrame";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { trpc } from "../lib/trpc";
import { parseStoredUser } from "../session";

export default function RoleAttendance() {
  const user = parseStoredUser(localStorage.getItem("northstarUser"));
  const requesterId = user?.id || 0;
  const summary = trpc.attendance.summary.useQuery({ requesterId }, { enabled: Boolean(requesterId) });
  const mark = trpc.attendance.mark.useMutation({ onSuccess: () => { summary.refetch(); toast.success("Attendance updated and visible in the shared summary."); } });
  if (!user || !["faculty", "admin"].includes(user.role)) return <FeatureFrame eyebrow="STUDENT SERVICES / ATTENDANCE" title="Attendance access restricted."><Card className="mt-8"><CardContent className="p-6 text-sm text-ink/60">Only Faculty and Admin accounts can manage or summarize institution attendance.</CardContent></Card></FeatureFrame>;
  const rows = summary.data || [];
  const rate = rows.length ? Math.round(rows.reduce((total, row) => total + (row.conductedClasses ? row.presentClasses / row.conductedClasses : 0), 0) / rows.length * 100) : 0;
  return <FeatureFrame eyebrow={`NORTHSTAR / ${user.role.toUpperCase()} ATTENDANCE`} title="Attendance, made visible."><div className="mt-8 grid gap-4 sm:grid-cols-3"><Card><CardContent className="p-5"><p className="eyebrow text-ink/45">Records</p><p className="mt-2 font-display text-4xl">{rows.length}</p></CardContent></Card><Card><CardContent className="p-5"><p className="eyebrow text-ink/45">Average present</p><p className="mt-2 font-display text-4xl">{rate}%</p></CardContent></Card><Card className="bg-gold"><CardContent className="p-5"><p className="eyebrow text-ink/60">Shared workflow</p><p className="mt-2 text-sm leading-6">Faculty updates are reflected here for Admin review.</p></CardContent></Card></div><Card className="mt-8"><CardHeader><CardTitle className="font-display text-2xl">Course attendance records</CardTitle></CardHeader><CardContent className="space-y-3">{rows.length ? rows.map(row => { const percentage = row.conductedClasses ? Math.round(row.presentClasses / row.conductedClasses * 100) : 0; const nextStatus = row.status === "present" ? "absent" : "present"; return <div key={row.id} className="flex flex-col gap-4 rounded-2xl bg-cream p-4 sm:flex-row sm:items-center"><div className="flex-1"><p className="font-semibold">{row.subject}</p><p className="mt-1 text-xs text-ink/50">Student account {row.accountId} · {new Date(row.classDate).toLocaleDateString()} · {row.presentClasses}/{row.conductedClasses} present</p></div><Badge variant={row.status === "absent" ? "destructive" : "outline"}>{row.status} · {percentage}%</Badge><Button size="sm" className="bg-forest text-ivory hover:bg-forest/90" disabled={mark.isPending} onClick={() => mark.mutate({ requesterId, id: row.id, status: nextStatus, presentClasses: Math.max(0, Math.min(row.conductedClasses, row.presentClasses + (nextStatus === "present" ? 1 : -1))) })}>{nextStatus === "present" ? "Mark present" : "Mark absent"}</Button></div>; }) : <p className="text-sm text-ink/55">No attendance records have been seeded yet.</p>}</CardContent></Card></FeatureFrame>;
}
