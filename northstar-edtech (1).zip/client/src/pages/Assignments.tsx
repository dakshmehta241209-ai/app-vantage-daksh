import { useState } from "react";
import FeatureFrame from "@/components/FeatureFrame";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { trpc } from "../lib/trpc";
import { parseStoredUser } from "../session";

function ReviewSubmission({ item, reviewerAccountId, onSaved }: { item: { id: number; studentAccountId: number; response: string; status: string; feedback: string | null; grade: number | null }; reviewerAccountId: number; onSaved: () => void }) {
  const [feedback, setFeedback] = useState(item.feedback || ""); const [grade, setGrade] = useState(item.grade?.toString() || ""); const review = trpc.assignments.review.useMutation({ onSuccess: () => { onSaved(); toast.success("Feedback and grade saved."); } });
  return <div className="rounded-2xl bg-cream p-4"><div className="flex items-center justify-between"><p className="text-sm font-semibold">Student account {item.studentAccountId}</p><Badge>{item.status}</Badge></div><p className="mt-3 text-sm leading-6 text-ink/65">{item.response}</p><div className="mt-3 grid gap-2 sm:grid-cols-[1fr_7rem_auto]"><Input value={feedback} onChange={e => setFeedback(e.target.value)} placeholder="Feedback" /><Input value={grade} onChange={e => setGrade(e.target.value)} type="number" min="0" placeholder="Grade" /><Button size="sm" disabled={review.isPending || (!feedback.trim() && !grade)} onClick={() => review.mutate({ reviewerAccountId, id: item.id, feedback: feedback.trim() || undefined, grade: grade ? Number(grade) : undefined })}>{review.isPending ? "Saving…" : "Save review"}</Button></div></div>;
}

export default function Assignments() {
  const user = parseStoredUser(localStorage.getItem("northstarUser"));
  const role = user?.role || "student";
  const accountId = user?.id || 0;
  const assignments = trpc.assignments.list.useQuery();
  const create = trpc.assignments.create.useMutation({ onSuccess: () => { assignments.refetch(); toast.success("Assignment created and visible to students."); } });
  const [title, setTitle] = useState("");
  const [courseCode, setCourseCode] = useState("CSE 304");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [points, setPoints] = useState("100");
  const [selected, setSelected] = useState<number | null>(null);
  const [response, setResponse] = useState("");
  const submissions = trpc.assignments.submissions.useQuery({ assignmentId: selected || undefined });
  const submit = trpc.assignments.submit.useMutation({ onSuccess: () => { submissions.refetch(); setResponse(""); toast.success("Response submitted for faculty review."); } });

  if (!user) return <FeatureFrame eyebrow="NORTHSTAR / ASSIGNMENTS" title="Sign in to view assignments."><Card className="mt-8"><CardContent className="p-6 text-sm text-ink/60">Your assignment workspace is available after sign-in.</CardContent></Card></FeatureFrame>;

  return <FeatureFrame eyebrow={`NORTHSTAR / ${role.toUpperCase()} ASSIGNMENTS`} title="Work that moves learning forward.">
    {role === "faculty" || role === "admin" ? <Card className="mt-8 max-w-3xl"><CardHeader><CardTitle className="font-display text-2xl">Create an assignment</CardTitle></CardHeader><CardContent className="grid gap-4 sm:grid-cols-2"><Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Assignment title" /><Input value={courseCode} onChange={e => setCourseCode(e.target.value)} placeholder="Course code" /><Textarea className="sm:col-span-2" value={description} onChange={e => setDescription(e.target.value)} placeholder="Describe the brief and expected response" /><Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} /><Input type="number" value={points} onChange={e => setPoints(e.target.value)} placeholder="Points" /><Button className="bg-forest text-ivory hover:bg-forest/90 sm:col-span-2" disabled={create.isPending} onClick={() => { if (!title.trim() || !description.trim() || !dueDate || !accountId) return toast.error("Complete the title, brief, and due date."); create.mutate({ facultyAccountId: accountId, title, courseCode, description, dueDate: new Date(`${dueDate}T23:59:00`), points: Number(points) || undefined }); }}> {create.isPending ? "Creating…" : "Create assignment"}</Button></CardContent></Card> : null}
    <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr]"> <Card><CardHeader><CardTitle className="font-display text-2xl">Assignment list</CardTitle></CardHeader><CardContent className="space-y-3">{assignments.isLoading ? <p className="text-sm text-ink/50">Loading assignments…</p> : assignments.data?.length ? assignments.data.map(item => <button key={item.id} onClick={() => setSelected(item.id)} className={`w-full rounded-2xl border p-4 text-left transition ${selected === item.id ? "border-forest bg-cream" : "border-ink/10 hover:bg-cream"}`}><div className="flex items-start justify-between gap-3"><div><p className="font-semibold">{item.title}</p><p className="mt-1 text-sm text-ink/55">{item.courseCode} · Due {new Date(item.dueDate).toLocaleDateString()}</p></div><Badge variant="outline">{item.points || "—"} pts</Badge></div><p className="mt-3 text-sm leading-6 text-ink/60">{item.description}</p></button>) : <p className="text-sm text-ink/55">No assignments yet. Faculty can create the first brief above.</p>}</CardContent></Card>
      <Card><CardHeader><CardTitle className="font-display text-2xl">{role === "student" ? "Submit your response" : "Submission review queue"}</CardTitle></CardHeader><CardContent className="space-y-4">{!selected ? <p className="text-sm text-ink/55">Select an assignment to continue.</p> : role === "student" ? <><Textarea value={response} onChange={e => setResponse(e.target.value)} placeholder="Write your response or paste a file placeholder link" /><Button className="bg-forest text-ivory hover:bg-forest/90" disabled={submit.isPending || !response.trim()} onClick={() => submit.mutate({ assignmentId: selected, studentAccountId: accountId, response })}> {submit.isPending ? "Submitting…" : "Submit response"}</Button></> : submissions.data?.length ? submissions.data.map(item => <ReviewSubmission key={item.id} item={item} reviewerAccountId={accountId} onSaved={() => submissions.refetch()} />) : <p className="text-sm text-ink/55">No submissions yet. Student responses will appear here.</p>}</CardContent></Card>
    </div>
  </FeatureFrame>;
}
