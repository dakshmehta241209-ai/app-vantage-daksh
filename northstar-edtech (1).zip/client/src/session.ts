export type Role = "student" | "faculty" | "coordinator" | "admin";

export type NorthstarUser = { id?: number; name: string; email: string; role: Role; username?: string; profileJson?: string | null };

export const DEFAULT_USER: NorthstarUser = { name: "Northstar user", username: "Northstar user", email: "", role: "student" };

export function getDisplayName(user: NorthstarUser | null | undefined) {
  const raw = user?.username?.trim() || user?.name?.trim() || user?.email?.split("@")[0]?.trim() || DEFAULT_USER.name;
  return raw.includes("@") ? raw.split("@")[0].trim() : raw;
}

export function getInitials(name: string) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]?.toUpperCase()).join("");
  return initials || "NU";
}

export function serializeUser(user: NorthstarUser) {
  return JSON.stringify(user);
}

export function parseStoredUser(raw: string | null): NorthstarUser | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as Partial<NorthstarUser>;
    if (!parsed || typeof parsed !== "object" || !parsed.role) return null;
    const parsedName = String(parsed.username || parsed.name || parsed.email?.split("@")[0] || DEFAULT_USER.name).trim();
    const name = parsedName.includes("@") ? parsedName.split("@")[0].trim() : parsedName;
    return { ...DEFAULT_USER, ...parsed, name, username: name };
  } catch {
    return null;
  }
}
