import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Bell, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { getDisplayName, getInitials, parseStoredUser } from "../session";

export default function FeatureFrame({ title, eyebrow, children }: { title: string; eyebrow: string; children: React.ReactNode }) {
  const [, navigate] = useLocation();
  const user = parseStoredUser(localStorage.getItem("northstarUser"));
  useEffect(() => { if (!user) navigate("/choose-role"); }, [navigate, user]);
  const logout = () => { localStorage.removeItem("northstarUser"); localStorage.removeItem("northstarRole"); navigate("/"); };
  if (!user) return null;
  return <div className="min-h-screen bg-ivory text-ink"><header className="sticky top-0 z-20 border-b border-ink/10 bg-ivory/95 backdrop-blur"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-8"><Link href={`/${user.role}/dashboard`} className="flex items-center gap-2 text-sm font-semibold text-forest"><ArrowLeft size={16} /> Back to dashboard</Link><div className="flex items-center gap-3"><Link href="/notifications" className="rounded-full p-2 text-ink/50 hover:bg-ink/5"><Bell size={17} /></Link><Avatar className="h-8 w-8"><AvatarFallback className="bg-gold text-xs">{getInitials(getDisplayName(user))}</AvatarFallback></Avatar><span className="hidden text-sm font-semibold sm:block">{getDisplayName(user)}</span><Button variant="ghost" size="icon" onClick={logout} aria-label="Sign out"><LogOut size={16} /></Button></div></div></header><main className="mx-auto max-w-7xl px-5 py-8 md:px-8 md:py-10"><p className="eyebrow text-forest">{eyebrow}</p><h1 className="mt-3 font-display text-5xl leading-none tracking-tight">{title}</h1>{children}</main></div>;
}
